﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Unclutter
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        public enum TaskPriority
        {
            Low,
            Medium,
            High
        }

        class Task
        {
            public string Description { get; set; }
            public bool IsCompleted { get; set; }
            public TaskPriority Priority { get; set; }
        }

        private void AddTask_Click(object sender, RoutedEventArgs e)
        {
            string taskDescription = taskInput.Text;
            if (!string.IsNullOrWhiteSpace(taskDescription))
            {
                DateTime? dueDate = dueDatePicker.SelectedDate; // Get the selected due date
                TaskPriority selectedPriority = (TaskPriority)Enum.Parse(typeof(TaskPriority), ((ComboBoxItem)priorityComboBox.SelectedItem).Content.ToString());

                string dueDateText = (dueDate.HasValue) ? dueDate.Value.ToShortDateString() : "No due date";
                taskListBox.Items.Add(new ListBoxItem
                {
                    Content = $"{taskDescription} (Due: {dueDateText}, Priority: {selectedPriority})"
                });
                taskInput.Clear();
                dueDatePicker.SelectedDate = null; // Clear the selected due date
            }
        }
        private void BackgroundComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (backgroundComboBox.SelectedItem != null)
            {
                string selectedBackgroundColor = ((ComboBoxItem)backgroundComboBox.SelectedItem).Tag.ToString();

                // Set the background color of the taskListBox
                switch (selectedBackgroundColor)
                {
                    case "White":
                        taskListBox.Background = Brushes.White;
                        break;
                    case "LightGray":
                        taskListBox.Background = Brushes.LightGray;
                        break;
                    case "SkyBlue":
                        taskListBox.Background = Brushes.SkyBlue;
                        break;
                        // Add more cases for additional background colors
                }
            }
        }

    }
}

